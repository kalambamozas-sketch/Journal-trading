# Trading Journal Pro — package PWA / Android

## Ce qui a été corrigé dans index.html

**Bug "créer un compte / s'inscrire" :**
- Les messages d'erreur Firebase bruts (en anglais, illisibles) sont maintenant traduits
  en français clair (email déjà utilisé, mot de passe trop court, pas de réseau, etc.).
- Le formulaire vérifie l'email et le mot de passe (6 caractères min.) AVANT d'appeler
  Firebase, au lieu de laisser l'utilisateur cliquer dans le vide.
- Si le service cloud n'est pas encore prêt au moment du clic (fréquent sur mobile /
  dans une app Android au démarrage), l'app retente automatiquement une fois avant
  d'afficher une erreur.
- Le chargement des données cloud attend 15s (+ un 2e essai) au lieu de 5s, pour éviter
  les faux messages "hors-ligne" sur réseau mobile lent.

**Cause la plus fréquente de ce bug dans une appli Android empaquetée :** dans la
console Firebase du projet `journal-tradin`, vérifiez ces deux réglages :
1. **Authentication → Sign-in method → Email/Password** doit être activé.
2. **Authentication → Settings → Authorized domains** doit contenir le domaine réel
   depuis lequel l'app tourne (le domaine Firebase Hosting ci-dessous est ajouté
   automatiquement).

Si le bug persiste après ça, notez le message d'erreur exact affiché à l'écran —
il y a maintenant un message précis pour chaque cas, ce qui permettra de cibler la
correction restante.

## Fichiers ajoutés (nécessaires pour qu'Android propose "Installer l'application")

- `manifest.json` — nom, icônes, couleurs de l'app
- `service-worker.js` — permet le fonctionnement hors-ligne de l'interface
- `icons/` — icônes 192px, 512px et 512px "maskable"
- `firebase.json` / `.firebaserc` — config prête pour héberger sur Firebase Hosting
  (le projet `journal-tradin` est déjà renseigné)

## Étape 1 — Héberger l'app en HTTPS (obligatoire pour l'installation Android)

Android/Chrome n'autorise l'installation d'une PWA que depuis une adresse HTTPS
(pas depuis un simple fichier). Le plus simple : Firebase Hosting, gratuit, et déjà
lié à votre projet Firebase existant.

```bash
npm install -g firebase-tools
firebase login
cd tjpro-pwa
firebase deploy --only hosting
```

Vous obtenez une adresse du type `https://journal-tradin.web.app`. Ouverte dans
Chrome sur Android, elle propose "Ajouter à l'écran d'accueil / Installer
l'application" — l'app s'installe alors avec sa propre icône, en plein écran,
comme une app native.

## Étape 2 — Obtenir un vrai fichier .apk installable sur n'importe quel téléphone

Je ne peux pas compiler un .apk directement dans cet environnement (il faut le
SDK Android + une connexion internet pour télécharger les outils de build, ce que
cet espace de travail n'a pas). La solution fiable et gratuite :

1. Allez sur **https://www.pwabuilder.com**
2. Collez l'URL obtenue à l'étape 1 (ex: `https://journal-tradin.web.app`)
3. Cliquez sur **"Android"** dans les packages proposés
4. Téléchargez le `.apk` (ou `.aab` si vous visez le Play Store) généré

Ce fichier `.apk` s'installe directement sur n'importe quel téléphone Android
(après avoir autorisé "Sources inconnues" dans les réglages), sans passer par le
Play Store.

## Alternative sans hébergement

Sans domaine à vous, vous pouvez utiliser un hébergement gratuit équivalent
(Netlify, Vercel, GitHub Pages) en y déposant ce même dossier — le résultat est
identique, seule l'étape 2 (PWABuilder) change d'URL de départ. Pensez alors à
ajouter ce nouveau domaine dans Firebase → Authentication → Authorized domains,
sinon la connexion/inscription échouera avec `auth/unauthorized-domain`.
