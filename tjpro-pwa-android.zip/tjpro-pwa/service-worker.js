// Service Worker - Trading Journal Pro
// Permet l'installation sur Android (critère PWA) + fonctionnement hors-ligne de l'interface.
// Les données (trades/profil) restent gérées par localStorage + Firebase, pas par ce cache.

const CACHE_NAME = 'tj-pro-shell-v1';
const APP_SHELL = [
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Ne jamais intercepter les appels Firebase / API externes : toujours réseau direct.
  if (req.url.includes('googleapis.com') || req.url.includes('firebaseio.com') || req.url.includes('gstatic.com')) {
    return;
  }

  // App shell : réseau d'abord, cache en secours (permet de voir les mises à jour rapidement).
  event.respondWith(
    fetch(req)
      .then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone)).catch(() => {});
        return res;
      })
      .catch(() => caches.match(req).then((cached) => cached || caches.match('./index.html')))
  );
});
